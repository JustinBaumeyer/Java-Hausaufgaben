package interfaces;

public interface Rechenoperation {
    /**
     * fuehrt eine Berechnung mit dem uebergebenen Wert aus
     * @param x
     * @return
     */
    double berechne(double x);
}
